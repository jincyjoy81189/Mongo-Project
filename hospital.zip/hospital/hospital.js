var express = require('express');
var app = express();
var bodyParser=require("body-parser"); 
const mongoose = require('mongoose'); 
mongoose.connect('mongodb://localhost:27017/hospitalsssss'); 
var db=mongoose.connection; 
db.on('error', console.log.bind(console, "Connection failed!")); 
app.use(bodyParser.json()); 
app.use(express.static('public')); 
app.use(bodyParser.urlencoded({ 
    extended: true
}));
app.set('view engine', 'ejs');
app.get('/', function(req, res) {
    res.render('index');
});
app.get('/record', function(req, res) {
  db.collection("record").find({}).toArray(function(err, result) {
    if (err) throw err;
    res.render('record',{result:result});
    db.close;
});});
app.post('/', function(req,res){ 
  var name = req.body.name;
  var roll= req.body.roll;
  var department=req.body.department;
  var mark=req.body.marks;  
  var write={"name": name,"roll":roll,"department":department }
  db.collection('record').insertOne(write,function(err, collection){ 
    if (err) throw err; 
    db.close;
});});
app.listen(3000);